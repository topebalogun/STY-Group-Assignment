﻿using System.ComponentModel.DataAnnotations;

namespace TFC_Booking_System.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        public string Code { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Image { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        [Range(0, 10000)]
        [DataType(DataType.Currency)]
        public double Price { get; set; }
        [Required]
        [Range(0, 10000)]
        [DataType(DataType.Currency)]
        public double ListPrice { get; set; }
    }
}
