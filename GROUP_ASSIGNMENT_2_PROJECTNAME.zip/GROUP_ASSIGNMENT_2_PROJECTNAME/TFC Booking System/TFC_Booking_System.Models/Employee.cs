﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TFC_Booking_System.Models
{
    public class Employee
    {
        [Key]
        public int EmployeeId { get; set; }
        public string FullName { get; set; }
        public string Image { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Nationality { get; set; }
        public string Address { get; set; }
        public DateTime DateCreated { get; set; }

        [ForeignKey("RoleId")]
        public Role Role { get; set; }

    }
}
