﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace TFC_Booking_System.Models
{
    public class ApplicationUser : IdentityUser
    {
        [ForeignKey("EmployeeId")]
        public int EmployeeId { get; set; }
    }
}
