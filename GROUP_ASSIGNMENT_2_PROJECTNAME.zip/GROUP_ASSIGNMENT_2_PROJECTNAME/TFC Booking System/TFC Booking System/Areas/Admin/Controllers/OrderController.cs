﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using TFC_Booking_System.Models;
using TFC_Booking_System.Repository;
using TFC_Booking_System.Utility;
using TFC_Booking_System.ViewModels;

namespace TFC_Booking_System.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize]
    public class OrderController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        [BindProperty]
        public OrderVM OrderVM { get; set; }
        public OrderController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IActionResult Index()
        {
            // Get current user
            var claimsIdentity = (ClaimsIdentity)User.Identity;
            var claim = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);
            // list all orders by current user
            IEnumerable<OrderHeader> orderHeader = _unitOfWork.OrderHeader.GetAllOrderHeaderById(claim.Value);
            return View(orderHeader);
        }

        public IActionResult Details(int orderId)
        {
            // get order header and order details from current user
            var orderHeader = _unitOfWork.OrderHeader.GetOrder(orderId);
            var orderDetail = _unitOfWork.OrderDetail.GetAllOrderDetailByOrderId(orderId);

            OrderVM = new OrderVM()
            {
                OrderHeader = orderHeader,
                OrderDetail = orderDetail
            };
            return View(OrderVM);
        }

        #region "API CALLS"
        [HttpGet]
        public IActionResult GetAll(string status)
        {
            IEnumerable<OrderHeader> orderHeaders;
            //orderHeaders = _unitOfWork.OrderHeader.GetAllOrderHeaders();

            //get all orders by front desk and kitchen manager role
            if (User.IsInRole(SD.Role_Employee_Manager) || User.IsInRole(SD.Role_Employee_FD))
            {
                orderHeaders = _unitOfWork.OrderHeader.GetAllOrderHeaders();
            }
            else
            {
                // get all orders by customer role
                var claimsIdentity = (ClaimsIdentity)User.Identity;
                var claim = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);
                orderHeaders = _unitOfWork.OrderHeader.GetAllOrderHeaderById(claim.Value);
            }

            // get all orders by order and payment status
            switch (status)
            {
                case "pending":
                    orderHeaders = orderHeaders.Where(u => u.PaymentStatus == SD.PaymentStatusPending);
                    break;
                case "inprocess":
                    orderHeaders = orderHeaders.Where(u => u.OrderStatus == SD.StatusInProcess);
                    break;
                case "completed":
                    orderHeaders = orderHeaders.Where(u => u.OrderStatus == SD.StatusShipped);
                    break;
                default:
                    break;
            }
            return Json(new { data = orderHeaders });
        }
        #endregion
    }
}
