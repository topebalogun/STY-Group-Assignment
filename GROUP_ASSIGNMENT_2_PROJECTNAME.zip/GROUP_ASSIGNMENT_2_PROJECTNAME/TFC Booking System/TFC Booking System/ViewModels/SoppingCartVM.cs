﻿using System.Collections.Generic;
using TFC_Booking_System.Models;

namespace TFC_Booking_System.ViewModels
{
    public class SoppingCartVM
    {
        public IEnumerable<ShoppingCart> ListCart { get; set; }
        public OrderHeader OrderHeader { get; set; }
    }
}
