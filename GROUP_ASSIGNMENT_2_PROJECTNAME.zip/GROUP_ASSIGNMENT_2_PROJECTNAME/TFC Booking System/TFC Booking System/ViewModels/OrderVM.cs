﻿using System.Collections.Generic;
using TFC_Booking_System.Models;

namespace TFC_Booking_System.ViewModels
{
    public class OrderVM
    {
        public OrderHeader OrderHeader { get; set; }
        public IEnumerable<OrderDetail> OrderDetail { get; set; }
    }
}
