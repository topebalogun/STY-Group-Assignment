﻿namespace TFC_Booking_System.DbInitialize
{
    public interface IDbInitializer
    {
        void Initialize();
    }
}
