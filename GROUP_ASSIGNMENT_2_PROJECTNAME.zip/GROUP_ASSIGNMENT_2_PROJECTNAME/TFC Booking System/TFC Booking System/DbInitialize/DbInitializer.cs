﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using TFC_Booking_System.Data;
using TFC_Booking_System.Models;
using TFC_Booking_System.Utility;

namespace TFC_Booking_System.DbInitialize
{
    public class DbInitializer : IDbInitializer
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<ApplicationRole> _roleManager;
        private readonly ApplicationDbContext _context;
        public DbInitializer(UserManager<ApplicationUser> userManager, RoleManager<ApplicationRole> roleManager, ApplicationDbContext context)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _context = context;
        }

        public void Initialize()
        {
            // migrations if they are not applied
            try
            {
                if(_context.Database.GetPendingMigrations().Count() > 0)
                {
                    _context.Database.Migrate();
                }
            }
            catch (System.Exception ex)
            {
                
            }


            //create roles if they are not created
            var getRoles = _roleManager.RoleExistsAsync(SD.Role_Admin).GetAwaiter().GetResult();
            if (!getRoles)
            {
                _roleManager.CreateAsync(new ApplicationRole
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = SD.Role_Admin,
                    DateCreated = DateTime.Now,
                    IsActive = true
                }).GetAwaiter().GetResult();
                _roleManager.CreateAsync(new ApplicationRole
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = SD.Role_User_Customer,
                    DateCreated = DateTime.Now,
                    IsActive = true
                }).GetAwaiter().GetResult();
                _roleManager.CreateAsync(new ApplicationRole
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = SD.Role_Employee_FD,
                    DateCreated = DateTime.Now,
                    IsActive = true
                }).GetAwaiter().GetResult();
                _roleManager.CreateAsync(new ApplicationRole
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = SD.Role_Employee_Manager,
                    DateCreated = DateTime.Now,
                    IsActive = true
                }).GetAwaiter().GetResult();
                //if roles are not created, then we will create admin user as well 

                _userManager.CreateAsync(new ApplicationUser
                {
                    Name = "Okoli Ifeamaka Annett",
                    UserName = "okoliifeamaka@gmail.com",
                    Email = "okoliifeamaka@gmail.com",
                    PhoneNumber = "+2348055474452",
                    StreetAddress = "Kat, TX Real Estate",
                    City = "Houston",
                    State = "Texas",
                    PostalCode = "77001"
                }, "Admin@123").GetAwaiter().GetResult();

                ApplicationUser user = _context.ApplicationUser.FirstOrDefault(u => u.Email == "okoliifeamaka@gmail.com");

                _userManager.AddToRoleAsync(user, SD.Role_User_Customer).GetAwaiter().GetResult();
                // get the images from the db and display on the website
                var products = new Product[]
                {
                    new Product
                    {
                        Name = "Burger",
                        Description = "For eating",
                        Image = @"images\products\cee992b1-f447-4a44-b709-56dd1a5a77d1.jpg",
                        Price = 17,
                        ListPrice = 20,
                        Price100 = 13,
                        Price50 = 14
                    },
                    new Product
                    {
                        Name = "Hot Dog",
                        Description = "For eating",
                        Image = @"images\products\332b75e2-4330-4ed4-ab23-7fe164ea0e91.webp",
                        Price = 17,
                        ListPrice = 20,
                        Price100 = 13,
                        Price50 = 14
                    },
                    new Product
                    {
                        Name = "Sandwich",
                        Description = "For eating",
                        Image = @"images\products\bread-gd85b736be_640.jpg",
                        Price = 17,
                        ListPrice = 20,
                        Price100 = 13,
                        Price50 = 14
                    },
                   
                };

                foreach (var i in products)
                {
                    _context.Product.Add(i);
                }
                _context.SaveChanges();
            }
            return;


        }
    }
}
