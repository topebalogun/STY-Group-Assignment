﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TFC_Booking_System.Models
{
    public class Role
    {
        [Key]
        public int RoleID { get; set; }
        public string RoleName { get; set; }
        public DateTime DateCreated { get; set; }
        public int CreatedBy { get; set; }

        [InverseProperty("Role")]
        public IEnumerable<Employee> Employees { get; set; }
    }
}
