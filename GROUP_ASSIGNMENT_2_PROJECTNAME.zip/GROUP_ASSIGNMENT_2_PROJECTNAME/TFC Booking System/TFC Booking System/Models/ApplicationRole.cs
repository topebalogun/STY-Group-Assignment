﻿using Microsoft.AspNetCore.Identity;
using System;

namespace TFC_Booking_System.Models
{
    public class ApplicationRole : IdentityRole<string>
    {
        public bool IsActive { get; set; }
        public int CanCreate { get; set; }
        public DateTime DateCreated { get; set; }
        public int? RoleID { get; set; }
        public ApplicationRole() : base()
        {
        }
        public ApplicationRole(string roleName) : base(roleName)
        {
            base.Name = roleName;
        }
    }
}
