﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TFC_Booking_System.Models
{
    public class Employee
    {
        [Key]
        public int EmployeeId { get; set; }
        [Required]
        public string FullName { get; set; }
        [Required]
        [ValidateNever]
        public string Image { get; set; }
        [Required]
        [DataType(DataType.PhoneNumber)]
        public string Mobile { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [ValidateNever]
        public DateTime DateOfBirth { get; set; }
        [Required]
        [ValidateNever]
        public string Nationality { get; set; }
        [Required]
        [DataType(DataType.MultilineText)]
        [ValidateNever]
        public string Address { get; set; }
        [DataType(DataType.Date)]
        public DateTime DateCreated { get; set; }

        [ForeignKey("RoleId")]
        public Role Role { get; set; }

    }
}
