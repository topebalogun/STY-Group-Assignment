﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TFC_Booking_System.Models;

namespace TFC_Booking_System.Repository.Interface
{
    public interface IRoleRepository : IRepository<Role>
    {
        List<Role> GetAllForDropdown();
        Role FindByRoleName(string name);
        Task<List<Role>> GetRoles();
        Task<Role> GetRoleById(int id);
    }
}
