﻿using System.Collections.Generic;
using TFC_Booking_System.Models;

namespace TFC_Booking_System.Repository.Interface
{
    public interface IOrderHeaderRepository : IRepository<OrderHeader>
    {
        void Update(OrderHeader obj);
        void UpdateStatus(int id, string orderStatus, string? paymentStatus = null);
        OrderHeader GetOrderHeader(string id);
        List<OrderHeader> GetAllOrderHeaders();
        IEnumerable<OrderHeader> GetAllOrderHeaderById(string id);
        OrderHeader GetOrder(int id);
    }
}
