﻿using System.Collections.Generic;
using TFC_Booking_System.Models;

namespace TFC_Booking_System.Repository.Interface
{
    public interface IShoppingCartRepository : IRepository<ShoppingCart>
    {
        int IncrementCount(ShoppingCart shoppingCart, int count);
        int DecrementCount(ShoppingCart shoppingCart, int count);
        List<ShoppingCart> GetAllShoppingCartByUserId(string id);
    }
}
