﻿using System.Collections.Generic;
using TFC_Booking_System.Models;

namespace TFC_Booking_System.Repository.Interface
{
    public interface IOrderDetailRepository : IRepository<OrderDetail>
    {
        IEnumerable<OrderDetail> GetAllOrderDetailByOrderId(int id);
    }
}
