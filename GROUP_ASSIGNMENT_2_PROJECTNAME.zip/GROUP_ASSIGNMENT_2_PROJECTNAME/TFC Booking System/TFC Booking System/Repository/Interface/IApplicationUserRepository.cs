﻿using TFC_Booking_System.Models;

namespace TFC_Booking_System.Repository.Interface
{
    public interface IApplicationUserRepository : IRepository<ApplicationUser>
    {
    }
}
