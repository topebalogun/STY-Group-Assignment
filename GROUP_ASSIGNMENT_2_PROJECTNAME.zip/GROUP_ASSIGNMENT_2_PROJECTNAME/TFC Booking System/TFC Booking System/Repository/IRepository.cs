﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace TFC_Booking_System.Repository
{
    public interface IRepository<TEntity> where TEntity : class
    {
        #region "Sync Method"
        TEntity Add(TEntity entity);
        void AddRange(IEnumerable<TEntity> entities);
        IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> predicate);
        TEntity Get(int id);
        TEntity Get(long id);
        TEntity GetFirstOrDefault(Expression<Func<TEntity, bool>> filter);
        IEnumerable<TEntity> GetAll(Expression<Func<TEntity, bool>>? filter = null, string? includeProperties = null);
        TEntity Update(TEntity entity);
        void UpdateRange(IEnumerable<TEntity> entities);
        void Remove(TEntity entity);
        void RemoveRange(IEnumerable<TEntity> entities);
        int Count();
        int Count(Expression<Func<TEntity, bool>> predicate);
        TEntity FirstOrDefault(Expression<Func<TEntity, bool>> predicate);
        #endregion

        #region "Async Methods"
        Task AddAsync(TEntity entity);
        Task AddSaveAsync(TEntity entity);
        Task AddSaveRangeAsync(IEnumerable<TEntity> entities);
        Task UpdateSaveAsync(TEntity entity);
        Task UpdateSaveAsyncX(TEntity entity);
        Task UpdateRangeSaveAsync(IEnumerable<TEntity> entities);
        Task<IEnumerable<TEntity>> FindAsync(Expression<Func<TEntity, bool>> predicate);
        Task<TEntity> GetAsync(int id);

        #endregion
    }
}
