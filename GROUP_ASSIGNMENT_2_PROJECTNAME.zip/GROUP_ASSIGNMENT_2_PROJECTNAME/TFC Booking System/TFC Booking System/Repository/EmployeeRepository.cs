﻿using TFC_Booking_System.Data;
using TFC_Booking_System.Models;
using TFC_Booking_System.Repository.Interface;

namespace TFC_Booking_System.Repository
{
    public class EmployeeRepository : Repository<Employee>, IEmployeeRepository
    {
        ApplicationDbContext _context;
        public EmployeeRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }
    }
}
