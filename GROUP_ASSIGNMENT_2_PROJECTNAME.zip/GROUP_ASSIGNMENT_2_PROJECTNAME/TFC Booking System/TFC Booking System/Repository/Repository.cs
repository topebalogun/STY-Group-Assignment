﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using TFC_Booking_System.Data;

namespace TFC_Booking_System.Repository
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        protected readonly ApplicationDbContext _context;
        protected readonly DbSet<TEntity> _entities;
        protected readonly ILogger _logger;

        public Repository(ApplicationDbContext context)
        {
            _context = context;
            _entities = context.Set<TEntity>();
        }

        #region "Sync Method"
        public virtual TEntity Add(TEntity entity)
        {
            try
            {
                _entities.Add(entity);
                _context.SaveChanges();
                return entity;
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message + " : " + ex.InnerException + " : " + ex.StackTrace);
                return null;
            }
        }
        public void AddRange(IEnumerable<TEntity> entities)
        {
            _context.Set<TEntity>().AddRange(entities);
        }
        public IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> predicate)
        {
            return _context.Set<TEntity>().Where(predicate);
        }
        public TEntity Get(int id)
        {
            return _context.Set<TEntity>().Find(id);
        }
        public TEntity GetFirstOrDefault(Expression<Func<TEntity, bool>> filter)
        {
            IQueryable<TEntity> query = _entities;

            query = query.Where(filter);

            return query.FirstOrDefault();
        }
        public TEntity Get(long id)
        {
            return _context.Set<TEntity>().Find(id);
        }
        public IEnumerable<TEntity> GetAll(Expression<Func<TEntity, bool>>? filter = null, string? includeProperties = null)
        {
            IQueryable<TEntity> query = _entities;
            if(filter != null)
            {
                query = query.Where(filter);
            }
            if(includeProperties != null)
            {
                foreach(var includeProp in includeProperties.Split(new char[] { ','}))
                {
                    query = query.Include(includeProp);
                }
            }
            return _context.Set<TEntity>()
            .ToList();
        }
        public virtual TEntity Update(TEntity entity)
        {
            try
            {
                _entities.Update(entity);
                _context.SaveChanges();
                return entity;
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message + " : " + ex.InnerException + " : " + ex.StackTrace);
                return null;
            }
        }
        public void UpdateRange(IEnumerable<TEntity> entities)
        {
            _context.Entry(entities).State = EntityState.Modified;
        }
        public void Remove(TEntity entity)
        {
            _context.Set<TEntity>().Remove(entity);
        }
        public void RemoveRange(IEnumerable<TEntity> entities)
        {
            _context.Set<TEntity>().RemoveRange(entities);
        }
        public virtual int Count()
        {
            return _entities.Count();
        }
        public virtual int Count(Expression<Func<TEntity, bool>> predicate)
        {
            return _entities.Where(predicate).Count();
        }
        public virtual TEntity FirstOrDefault(Expression<Func<TEntity, bool>> predicate)
        {
            return _entities.FirstOrDefault(predicate);
        }
        #endregion

        #region "Async Methods"
        public async Task<TEntity> Get(dynamic id)
        {
            return await _context.Set<TEntity>().Find(id);
        }

        public async Task AddAsync(TEntity entity)
        {
            await _context.Set<TEntity>().AddAsync(entity);
        }

        public async Task AddSaveAsync(TEntity entity)
        {
            await _context.Set<TEntity>().AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task AddSaveRangeAsync(IEnumerable<TEntity> entities)

        {
            await _context.Set<TEntity>().AddRangeAsync(entities);
            await _context.SaveChangesAsync();
        }
        public async Task AddRangeAsync(IEnumerable<TEntity> entities)
        {
            await _context.Set<TEntity>().AddRangeAsync(entities);
        }

        public async Task<IEnumerable<TEntity>> FindAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await _context.Set<TEntity>().Where(predicate).ToListAsync();
        }

        public async Task<TEntity> GetAsync(int id)
        {
            return await _context.Set<TEntity>().FindAsync(id);
        }

        public async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            return await _context.Set<TEntity>().ToListAsync();
        }

        public void UpdateAsync(TEntity entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
        }

        public async Task UpdateSaveAsync(TEntity entity)
        {
            //context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task UpdateSaveAsyncX(TEntity entity)
        {
            _context.Attach(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task UpdateRangeSaveAsync(IEnumerable<TEntity> entities)
        {
            foreach (var entity in entities)
            {
                _context.Entry(entity).State = EntityState.Modified;
            }
            await _context.SaveChangesAsync();
        }

        public async Task RemoveAsync(TEntity entity)
        {
            await _context.Set<TEntity>().Remove(entity).ReloadAsync();
        }

        public void RemoveRangeAsync(IEnumerable<TEntity> entities)
        {
            _context.Set<TEntity>().RemoveRange(entities);
        }

        #endregion
    }
}
