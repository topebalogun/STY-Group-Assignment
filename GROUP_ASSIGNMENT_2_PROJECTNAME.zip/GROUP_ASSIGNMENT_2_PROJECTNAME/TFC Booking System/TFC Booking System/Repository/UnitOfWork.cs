﻿using System.Threading.Tasks;
using TFC_Booking_System.Data;
using TFC_Booking_System.Repository.Interface;

namespace TFC_Booking_System.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private ApplicationDbContext _context;

        #region "Lock"
        private static readonly object _Instancelock = new object();
        #endregion

        #region "Interface"
        IRoleRepository _Role;
        IEmployeeRepository _Employee;
        IProductRepository _Product;
        IShoppingCartRepository _ShoppingCart;
        IApplicationUserRepository _ApplicationUser;
        IOrderHeaderRepository _OrderHeader;
        IOrderDetailRepository _OrderDetail;
        #endregion

        public UnitOfWork(ApplicationDbContext context)
        {
            _context = context;
        }

        public IRoleRepository Role
        {
            get
            {
                if (_Role == null)
                {
                    lock (_Instancelock)
                    {
                        if (_Role == null)
                            _Role = new RoleRepository(_context);
                    }
                }

                return _Role;
            }
        }

        public IEmployeeRepository Employee
        {
            get
            {
                if (_Employee == null)
                {
                    lock (_Instancelock)
                    {
                        if (_Employee == null)
                            _Employee = new EmployeeRepository(_context);
                    }
                }

                return _Employee;
            }
        }

        public IProductRepository Product
        {
            get
            {
                if (_Product == null)
                {
                    lock (_Instancelock)
                    {
                        if (_Product == null)
                            _Product = new ProductRepository(_context);
                    }
                }

                return _Product;
            }
        }

        public IShoppingCartRepository ShoppingCart
        {
            get
            {
                if (_ShoppingCart == null)
                {
                    lock (_Instancelock)
                    {
                        if (_ShoppingCart == null)
                            _ShoppingCart = new ShoppingCartRepository(_context);
                    }
                }

                return _ShoppingCart;
            }
        }

        public IOrderHeaderRepository OrderHeader
        {
            get
            {
                if (_OrderHeader == null)
                {
                    lock (_Instancelock)
                    {
                        if (_OrderHeader == null)
                            _OrderHeader = new OrderHeaderRepository(_context);
                    }
                }

                return _OrderHeader;
            }
        }

        public IOrderDetailRepository OrderDetail
        {
            get
            {
                if (_OrderDetail == null)
                {
                    lock (_Instancelock)
                    {
                        if (_OrderDetail == null)
                            _OrderDetail = new OrderDetailRepository(_context);
                    }
                }

                return _OrderDetail;
            }
        }

        public IApplicationUserRepository ApplicationUser
        {
            get
            {
                if (_ApplicationUser == null)
                {
                    lock (_Instancelock)
                    {
                        if (_ApplicationUser == null)
                            _ApplicationUser = new ApplicationUserRepository(_context);
                    }
                }

                return _ApplicationUser;
            }
        }

        public int Complete()
        {
            return _context.SaveChanges();
        }

        public async Task<int> CompleteAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
