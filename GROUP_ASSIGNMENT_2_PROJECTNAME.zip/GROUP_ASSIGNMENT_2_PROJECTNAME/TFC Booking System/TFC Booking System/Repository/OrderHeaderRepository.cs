﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using TFC_Booking_System.Data;
using TFC_Booking_System.Models;
using TFC_Booking_System.Repository.Interface;

namespace TFC_Booking_System.Repository
{
    public class OrderHeaderRepository : Repository<OrderHeader>, IOrderHeaderRepository
    {
        ApplicationDbContext _context;
        public OrderHeaderRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }

        public void Update(OrderHeader obj)
        {
            _context.OrderHeader.Update(obj);
        }

        public void UpdateStatus(int id, string orderStatus, string? paymentStatus = null)
        {
            var orderFromDb = _context.OrderHeader.FirstOrDefault(u => u.Id == id);
            if(orderFromDb != null)
            {
                orderFromDb.OrderStatus = orderStatus;
                if(paymentStatus != null)
                {
                    orderFromDb.PaymentStatus = paymentStatus;
                }
            }
        }

        public OrderHeader GetOrderHeader(string id)
        {
            var orderHeader = _context.OrderHeader
                .Include(u => u.ApplicationUser)
                .Where(u => u.ApplicationUserId == id)
                .AsNoTracking()
                .FirstOrDefault();
            return orderHeader;
        }

        public OrderHeader GetOrder(int id)
        {
            var orderHeader = _context.OrderHeader
                .Include(u => u.ApplicationUser)
                .Where(u => u.Id == id)
                .AsNoTracking()
                .FirstOrDefault();
            return orderHeader;
        }

        public IEnumerable<OrderHeader> GetAllOrderHeaderById(string id)
        {
            var orderHeader = _context.OrderHeader
                .Include(u => u.ApplicationUser)
                .Where(u => u.ApplicationUserId == id)
                .AsNoTracking()
                .ToList();
            return orderHeader;
        }

        public List<OrderHeader> GetAllOrderHeaders()
        {
            var orderHeaders = _context.OrderHeader
                .Include(u => u.ApplicationUser)
                .AsNoTracking()
                .ToList();
            return orderHeaders;
        }
    }
}
