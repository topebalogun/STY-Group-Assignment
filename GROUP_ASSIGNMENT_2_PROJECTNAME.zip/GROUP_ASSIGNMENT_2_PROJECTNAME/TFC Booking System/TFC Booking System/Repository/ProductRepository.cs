﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using TFC_Booking_System.Data;
using TFC_Booking_System.Models;
using TFC_Booking_System.Repository.Interface;

namespace TFC_Booking_System.Repository
{
    public class ProductRepository : Repository<Product>, IProductRepository
    {
        ApplicationDbContext _context;
        public ProductRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }

        public void Update(Product obj)
        {
            var objFromDb = _context.Product.FirstOrDefault(u => u.ProductId == obj.ProductId);
            if(objFromDb != null)
            {
                objFromDb.Name = obj.Name;
                objFromDb.Price = obj.Price;
                objFromDb.Description = obj.Description;
                objFromDb.ListPrice = obj.ListPrice;
                objFromDb.Code = obj.Code;
                if(obj.Image != null)
                {
                    objFromDb.Image = obj.Image;
                }
            }
        }
    }
}
