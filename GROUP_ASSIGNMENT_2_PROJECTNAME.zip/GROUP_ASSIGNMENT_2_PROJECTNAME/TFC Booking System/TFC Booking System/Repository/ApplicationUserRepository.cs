﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using TFC_Booking_System.Data;
using TFC_Booking_System.Models;
using TFC_Booking_System.Repository.Interface;

namespace TFC_Booking_System.Repository
{
    public class ApplicationUserRepository : Repository<ApplicationUser>, IApplicationUserRepository
    {
        ApplicationDbContext _context;
        public ApplicationUserRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }

    }
}
