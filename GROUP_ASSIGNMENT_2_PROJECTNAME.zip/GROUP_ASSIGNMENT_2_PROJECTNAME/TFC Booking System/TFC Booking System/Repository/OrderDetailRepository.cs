﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using TFC_Booking_System.Data;
using TFC_Booking_System.Models;
using TFC_Booking_System.Repository.Interface;

namespace TFC_Booking_System.Repository
{
    public class OrderDetailRepository : Repository<OrderDetail>, IOrderDetailRepository
    {
        ApplicationDbContext _context;
        public OrderDetailRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }

        public IEnumerable<OrderDetail> GetAllOrderDetailByOrderId(int id)
        {
            var orderDetail = _context.OrderDetail
                .Include(o => o.Product)
                .Include(o => o.OrderHeader)
                .AsNoTracking()
                .ToList();
            return orderDetail;
        }
    }
}
