﻿using System;
using System.Threading.Tasks;
using TFC_Booking_System.Repository.Interface;

namespace TFC_Booking_System.Repository
{
    public interface IUnitOfWork : IDisposable
    {
        IRoleRepository Role { get; }
        IEmployeeRepository Employee { get; }
        IProductRepository Product { get; }
        IApplicationUserRepository ApplicationUser { get; }
        IShoppingCartRepository ShoppingCart { get; }
        IOrderDetailRepository OrderDetail { get; }
        IOrderHeaderRepository OrderHeader { get; }
        int Complete();
        Task<int> CompleteAsync();
    }
}
