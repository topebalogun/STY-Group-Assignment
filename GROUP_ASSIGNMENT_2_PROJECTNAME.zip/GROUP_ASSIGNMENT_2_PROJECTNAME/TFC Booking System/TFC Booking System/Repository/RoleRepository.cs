﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TFC_Booking_System.Data;
using TFC_Booking_System.Models;
using TFC_Booking_System.Repository.Interface;

namespace TFC_Booking_System.Repository
{
    public class RoleRepository : Repository<Role>, IRoleRepository
    {
        ApplicationDbContext _context;

        public RoleRepository(ApplicationDbContext context) : base(context)
        {
            _context = context;
        }

        public List<Role> GetAllForDropdown()
        {
            return _context.Role.ToList();
        }

        public Role FindByRoleName(string name)
        {
            var role = _context.Role
                .Where(x => x.RoleName == name)
                .FirstOrDefault();
            return role;
        }

        public async Task<List<Role>> GetRoles()
        {
            try
            {
                var role = await _context.Role
                .ToListAsync();
                return role;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<Role> GetRoleById(int id)
        {
            try
            {
                var role = await _context.Role
                    .Where(x => x.RoleID == id)
                    .AsNoTracking()
                    .FirstOrDefaultAsync();
                return role;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
